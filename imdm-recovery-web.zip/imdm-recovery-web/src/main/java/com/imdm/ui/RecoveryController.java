package com.imdm.ui;

import java.io.IOException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

//@CrossOrigin(origins="http://localhost:4200")
@RestController
public class RecoveryController {

	
		private static String displayName;
		private String recoveryStatus="NA";
		
		
		public static void setDisplayName(String name) {
			displayName=name;
		}
		@RequestMapping(value = "/sample",method = RequestMethod.GET)
		public ModelAndView getViewName(Model model,HttpServletRequest request,HttpServletResponse response) throws IOException {
			
			
			HttpSession session = request.getSession();
			session.setAttribute("username",displayName);
			ModelAndView view = new ModelAndView(); 
			model.addAttribute("username",displayName);
			view.setViewName("recovery-ui");
			
			response.addHeader("username", displayName);
			response.setHeader("username", displayName);
			//response.sendRedirect(request.getRequestURL()+"welcome");
			return view;
		}
		
		@RequestMapping(value = "/displayname",method = RequestMethod.GET)
		public String getDisplayName() {
			
			return displayName;
		}
		@RequestMapping(value = "/status",method = RequestMethod.GET)
		public String getRecoveryStatus() {
			
			return recoveryStatus;
		}

		
		@RequestMapping(value = "/recovery-ui",method = RequestMethod.GET)
		public ModelAndView welcome(Model model,HttpServletRequest request,HttpServletResponse response) {
			HttpSession session = request.getSession();
			session.setAttribute("username",displayName);
			
			response.setHeader("username", displayName);
			
			ModelAndView view = new ModelAndView(); 
			model.addAttribute("username",displayName);
			view.setViewName("recovery-ui");
			return view;
		}
		
		
		
		
		@RequestMapping(value = "/cdb",method = RequestMethod.GET)
		public ModelAndView getCDB(Model model,HttpServletRequest request) {
			HttpSession session = request.getSession();
			session.setAttribute("username",displayName);
			
			ModelAndView view = new ModelAndView(); 
			model.addAttribute("src", "cdb");
			model.addAttribute("username",displayName);
			view.setViewName("recovery-ui");
			return view;
		}
		
		@RequestMapping(value = "/csp",method = RequestMethod.GET)
		public ModelAndView getCSP(Model model,HttpServletRequest request) {
			HttpSession session = request.getSession();
			session.setAttribute("username",displayName);
			
			ModelAndView view = new ModelAndView(); 
			model.addAttribute("src", "csp");
			model.addAttribute("username",displayName);
			view.setViewName("recovery-ui");
			return view;
		}
		
		@RequestMapping(value = "/ocd",method = RequestMethod.GET)
		public ModelAndView getOCD(Model model,HttpServletRequest request) {
			HttpSession session = request.getSession();
			session.setAttribute("username",displayName);
			
			ModelAndView view = new ModelAndView();
			model.addAttribute("src", "ocd");
			model.addAttribute("username",displayName);
			view.setViewName("recovery-ui");
			return view;
		}
		
		@PostMapping(value = "/result/{srccode}/{recordval}")
		public String result(@PathVariable String name,@PathVariable String type,HttpServletRequest request) {
			HttpSession session = request.getSession();
			session.setAttribute("username",displayName);
			
			return "name is:"+name+"  type is :"+type;
		}
		@PostMapping(value = "/csp")
		public String resultCSP(Model model,@RequestParam("srccode") String sourceCode, @RequestParam("recordval") String memberId,HttpServletRequest httRequest) {
			
			return resulttwo(sourceCode, memberId, httRequest);
		}
		@PostMapping(value = "/ocd")
		public String resultOCD(Model model,@RequestParam("srccode") String sourceCode, @RequestParam("recordval") String memberId,HttpServletRequest httRequest) {
			
			return resulttwo(sourceCode, memberId, httRequest);
		}
		
		@RequestMapping(value = "/recovery",method = RequestMethod.GET)
		public ModelAndView getRecovery(@RequestParam("srccode") String sourceCode, @RequestParam("recordval") String memberId,HttpServletRequest httRequest) {
			ModelAndView view = new ModelAndView();
			recoveryStatus = resulttwo(sourceCode, memberId, httRequest);
			 view.setViewName("recovery-ui");
			 return view;
		}
		
		
		
		@PostMapping(value = "/cdb")
		public String resulttwo(@RequestParam("srccode") String sourceCode, @RequestParam("recordval") String memberId,HttpServletRequest httRequest) {
			HttpSession session = httRequest.getSession();
			session.setAttribute("username",displayName);
			
			Model model = null;
			String resp=null;
			String id = sourceCode+"|"+memberId;
			try {
			    String url = "http://imdm-rec-individualmdm.origin-ctc-core.optum.com/api/recovery/"+id;
			    String authStr = "imdmcicd:cal6Velo";
			    String base64Creds = Base64.getEncoder().encodeToString(authStr.getBytes());
			    HttpHeaders headers = new HttpHeaders();
			    headers.add("Authorization", "Basic " + base64Creds);
			    HttpEntity request = new HttpEntity(headers);
			    ResponseEntity<String> response = new RestTemplate().exchange(url, HttpMethod.GET, request, String.class);
			    String json = response.getBody();
			    resp = "Request has been Submitted Sucessfully";
			    recoveryStatus = "Request has been Submitted Sucessfully";
				//model.addAttribute("msg", "Request has been submitted successfully.");
			} catch (Exception ex) {
			    ex.printStackTrace();
			    //model.addAttribute("msg", "Something went wrong !!.");
			    resp = "Something went wrong !!.";
			    recoveryStatus = "Something went wrong !!.";
			}
			ModelAndView view = new ModelAndView(); 
			//view.setViewName("cdbView");
			String[] src = sourceCode.split("_");
			if(src.length > 1) {
				//model.addAttribute("src", "cdb");
			}else {
				//model.addAttribute("src", sourceCode);
			}
			//model.addAttribute("username",displayName);
			view.setViewName("recovery-ui");
			return resp;
		}
		
		
		@RequestMapping(value = "/welcome", method = RequestMethod.GET)
		public Map<String,String> welcome(HttpServletResponse response) {
			Map<String,String> mapwelcom = new HashMap<String, String>();
			mapwelcom.put("welcome","Welcome");
			mapwelcom.put("displayname", displayName);
			response.setHeader("Access-Control-Allow-Origin", "*");
			return mapwelcom;
		}
		
		@GetMapping(produces = "application/json")
		@RequestMapping({ "/validateLogin" })
		public User validateLogin() {
			return new User("User successfully authenticated", recoveryStatus, false, false, false, false, null);
		}
		
		@RequestMapping(value = "/login", method = RequestMethod.GET)
		public Map<String,String> loginPage(@RequestParam(value = "error",required = false) String error,
		@RequestParam(value = "logout",	required = false) String logout,@RequestParam(value = "success",required = false) String success,
		HttpServletRequest httpRequest,HttpServletResponse httpResponse) throws IOException {
			Map<String,String> map = new HashMap<String, String>();
			String response = null;
			if (error != null)
				response = "Bad Credentials";
				map.put("badcredentials",response);

			if (logout != null) {
				response = "You have been logout successfully";
				map.put("logout",response);
			}
			
			if(success != null) {
				response = "success";
				map.put("success",response);
				
				//redirectStrategy.sendRedirect(httpRequest, httpResponse, "/welcome");
				
			}
			map.put("userid", "sunil");
			//map.put("displayname", displayName);
			map.put("displayname", "Sunil Nagula - TEST NAME");
			
			//httpResponse.sendRedirect(httpRequest.getContextPath()+"welcome");
			ModelAndView view = new ModelAndView();
			view.setViewName("login");
			
			return map;
		}
		
		
}
