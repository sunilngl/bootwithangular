package com.imdm.ui;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImdmRecoveryUiApplicationTests {

	@Test
	void contextLoads() {
	}

}
